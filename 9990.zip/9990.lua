addappid(9990)
addappid(9992)
addappid(9991,0,"5e02f09462e7bceaaabea713a36cb5cc64674cde0d48de4e6df24ff9e6d13436")
setManifestid(9991,"6573600818039967594")